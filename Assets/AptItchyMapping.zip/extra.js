const noHoverProps = {
    
                        attrs: {
                            fill: "#828E82"
                        }
                        , attrsHover: {
                            fill: "#828E82"
                        },
                        target: "_blank"
                    
}

const msh = "gg";

const area_data = {
                    "Russia2": noHoverProps,
"Russia1": noHoverProps,
"Kazakhstan": noHoverProps,
"Uzbekistan": noHoverProps,
"Turkmenistan": noHoverProps,
"SaudiArabia": noHoverProps,
"Egypt": noHoverProps,
"Armenia": noHoverProps,
"Georgia": noHoverProps,
"Azerbaijan1": noHoverProps,
"Azerbaijan2": noHoverProps,
"Kuwait": noHoverProps,
"Lebanon": noHoverProps,
"Cyprus": noHoverProps,
"Jordan": noHoverProps,
"Israel": noHoverProps,
"Iran2": noHoverProps,
"Iran": noHoverProps,
"Turkey5": noHoverProps,
"Turkey4": noHoverProps,
"Turkey3": noHoverProps,
"Turkey2": noHoverProps,
"Turkey": noHoverProps,
"Syria": noHoverProps,
"Iraq2": noHoverProps,
"Iraq": noHoverProps,
                    "Eastern_Kurdistan": {
                        attrs: {
                            fill: "828E82"
                        }
                        , attrsHover: {
                            fill: "#a4e100"
                        },
                        target: "_blank",
                        add_text: "This is Eastern Kurdistan with 2 billion people"
                    },
                    "Northern_Kurdistan": {
                        attrs: {
                            fill: "#607B7D"
                        },
                        add_text: "This is Northern Kurdistan with 9 billion people"
                    }
                }


/* Open when someone clicks on the span element */
function openNav() {
  document.getElementById("myNav").style.width = "100%";
}

/* Close when someone clicks on the "x" symbol inside the overlay */
function closeNav() {
  document.getElementById("myNav").style.width = "0%";
}
//     noHoverProps = {
    
//                         attrs: {
//                             fill: "#828E82"
//                         }
//                         , attrsHover: {
//                             fill: "#828E82"
//                         },
//                         target: "_blank"
                    
// }

        $(function () {
            $(".mapcontainer").mapael({
                map: {
                    name: "kurdistan_area",
                    // Set default plots and areas style
                    defaultPlot: {
                        size: 30,
                        
                    
                        attrs: {
                            fill: "#004a9b"
                            , opacity: 0.6
                        }
                        , 
                        attrsHover: {
                            // opacity: 1
                        }
                        , 
                        text: {
                            attrs: {
                                fill: "#505444"
                            }
                            , attrsHover: {
                                fill: "#000"
                            }
                        }
                    }
                    , defaultArea: {
                        eventHandlers: {
                            click: function (e, id, mapElem, textElem, elemOptions) {
                                $('.test span').html(`<p> ${elemOptions.add_text}</p>`)
                                if(elemOptions.add_text){
                                    $('.overlay-content').html(elemOptions.add_text).css({fontSize: '49px'})
                                    console.log('asd')
                                    console.log(elemOptions.add_text)
                                }
                                console.log(msh)
                                openNav();
                               
                            }
                        },
                        attrs: {
                            fill: "#828E82"
                            , stroke: "#ced8d0"
                        }
                        , attrsHover: {
                            // fill: "#AAAE8E"
                        }
                        , text: {
                            attrs: {
                                fill: "#505444"
                            }
                            , attrsHover: {
                                // fill: "#000"
                            }
                        }
                    }
                },

                // Customize some areas of the map
                areas: area_data
           
            });
        });